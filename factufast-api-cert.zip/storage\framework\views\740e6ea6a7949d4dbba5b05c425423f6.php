<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Factura creada</title>
  <style>body{font-family:Arial,sans-serif;color:#111;}</style>
</head>
<body>
  <p>Hola equipo <?php echo e($invoice->company->name ?? ''); ?>,</p>
  <p>Se creó la factura #<?php echo e($invoice->invoice_number); ?> para el cliente <?php echo e($invoice->client->name ?? 'N/D'); ?> por $<?php echo e(number_format($invoice->amount, 2, ',', '.')); ?>.</p>
  <p>Emisión: <?php echo e(optional($invoice->issue_date)->format('d/m/Y')); ?> | Vencimiento: <?php echo e(optional($invoice->due_date)->format('d/m/Y')); ?></p>
  <p>— FactuFast</p>
</body>
</html>
<?php /**PATH C:\Users\nelso\Escritorio\Cosas de la U\Proyectos Practica\FactuFast\api\resources\views/emails/invoice_created_company.blade.php ENDPATH**/ ?>