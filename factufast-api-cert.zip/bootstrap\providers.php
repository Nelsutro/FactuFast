<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\OAuthServiceProvider::class,
];
