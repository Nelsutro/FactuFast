<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Factura #<?php echo e($invoice->invoice_number); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 12px; color: #111; }
        .header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 16px; }
        .company h2 { margin: 0 0 4px 0; font-size: 18px; }
        .muted { color: #666; }
        .box { border: 1px solid #ddd; padding: 8px; border-radius: 4px; }
        .title { font-size: 20px; margin: 0 0 8px 0; }
        .grid { display: flex; gap: 12px; }
        .col { flex: 1; }
        table { width: 100%; border-collapse: collapse; margin-top: 12px; }
        th, td { padding: 8px; border: 1px solid #ddd; }
        th { background: #f4f4f5; text-align: left; }
        .right { text-align: right; }
        .totals { margin-top: 8px; }
    </style>
</head>
<body>
    <div class="header">
        <div class="company">
            <h2><?php echo e($invoice->company->name ?? 'Empresa'); ?></h2>
            <div class="muted">RUT/NIF: <?php echo e($invoice->company->tax_id ?? '-'); ?></div>
            <div class="muted">Email: <?php echo e($invoice->company->email ?? '-'); ?></div>
            <div class="muted">Tel: <?php echo e($invoice->company->phone ?? '-'); ?></div>
            <div class="muted"><?php echo e($invoice->company->address ?? '-'); ?></div>
        </div>
        <div class="box">
            <div class="title">Factura #<?php echo e($invoice->invoice_number); ?></div>
            <div>Fecha emisión: <?php echo e(optional($invoice->issue_date)->format('d/m/Y')); ?></div>
            <div>Vencimiento: <?php echo e(optional($invoice->due_date)->format('d/m/Y')); ?></div>
            <div>Estado: <?php echo e(ucfirst($invoice->status)); ?></div>
        </div>
    </div>

    <div class="grid">
        <div class="col box">
            <strong>Facturar a</strong>
            <div><?php echo e($invoice->client->name ?? 'Cliente'); ?></div>
            <div class="muted"><?php echo e($invoice->client->email ?? '-'); ?></div>
            <div class="muted"><?php echo e($invoice->client->phone ?? '-'); ?></div>
            <div class="muted"><?php echo e($invoice->client->address ?? '-'); ?></div>
        </div>
    </div>

    <table>
        <thead>
            <tr>
                <th>Descripción</th>
                <th class="right">Cantidad</th>
                <th class="right">P. Unitario</th>
                <th class="right">Importe</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $invoice->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->description); ?></td>
                    <td class="right"><?php echo e(number_format($item->quantity, 2, ',', '.')); ?></td>
                    <td class="right"><?php echo e(number_format($item->unit_price, 2, ',', '.')); ?></td>
                    <td class="right"><?php echo e(number_format($item->amount, 2, ',', '.')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="right">Sin ítems</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <div class="totals">
        <div class="right"><strong>Total: </strong><?php echo e(number_format($invoice->amount, 2, ',', '.')); ?></div>
    </div>

    <?php if($invoice->notes): ?>
    <div class="box" style="margin-top:12px;">
        <strong>Notas</strong>
        <div><?php echo e($invoice->notes); ?></div>
    </div>
    <?php endif; ?>
</body>
</html>
<?php /**PATH C:\Users\nelso\Escritorio\Cosas de la U\Proyectos Practica\FactuFast\api\resources\views/pdf/invoice.blade.php ENDPATH**/ ?>